/**
 * Created by liuweixing on 2019/3/8.
 */
var winW = document.documentElement.clientWidth;
document.documentElement.style.fontSize     = winW / 7.5 + 'px';
